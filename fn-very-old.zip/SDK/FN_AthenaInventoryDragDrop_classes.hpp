#pragma once

// Fortnite (2.3.2) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "FN_AthenaInventoryDragDrop_structs.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass AthenaInventoryDragDrop.AthenaInventoryDragDrop_C
// 0x0001 (0x0089 - 0x0088)
class UAthenaInventoryDragDrop_C : public UDragDropOperation
{
public:
	bool                                               SplitTheStack;                                            // 0x0088(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
		static UClass* ptr;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("BlueprintGeneratedClass AthenaInventoryDragDrop.AthenaInventoryDragDrop_C"));

		return ptr;
	}


	void ShowDropIcon(TEnumAsByte<EAthenaDragDropAction> Drop_Action);
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
