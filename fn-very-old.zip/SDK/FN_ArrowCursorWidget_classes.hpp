#pragma once

// Fortnite (2.3.2) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "FN_ArrowCursorWidget_structs.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// WidgetBlueprintGenerated ArrowCursorWidget.ArrowCursorWidget_C
// 0x0000 (0x0208 - 0x0208)
class UArrowCursorWidget_C : public UUserWidget
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("WidgetBlueprintGenerated ArrowCursorWidget.ArrowCursorWidget_C"));

		return ptr;
	}


	struct FSlateBrush GetBackground_1();
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
