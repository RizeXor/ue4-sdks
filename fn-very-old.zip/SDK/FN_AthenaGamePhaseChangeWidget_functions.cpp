// Fortnite (2.3.2) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "FN_AthenaGamePhaseChangeWidget_parameters.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function AthenaGamePhaseChangeWidget.AthenaGamePhaseChangeWid.Simpl
// (Public, BlueprintCallable, BlueprintEvent)

void UAthenaGamePhaseChangeWid::Simpl()
{
	static UFunction* fn;

		if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AthenaGamePhaseChangeWidget.AthenaGamePhaseChangeWid.Simpl"));

	UAthenaGamePhaseChangeWid_Simpl_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AthenaGamePhaseChangeWidget.AthenaGamePhaseChangeWid.PlayIntroAnimation
// (Public, HasDefaults, BlueprintCallable, BlueprintEvent)
// Parameters:
// EAthenaGamePhaseStep           Step                           (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)

void UAthenaGamePhaseChangeWid::PlayIntroAnimation(EAthenaGamePhaseStep Step)
{
	static UFunction* fn;

		if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AthenaGamePhaseChangeWidget.AthenaGamePhaseChangeWid.PlayIntroAnimation"));

	UAthenaGamePhaseChangeWid_PlayIntroAnimation_Params params;
	params.Step = Step;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AthenaGamePhaseChangeWidget.AthenaGamePhaseChangeWid.PlayGamePhaseAlertSound
// (Public, BlueprintCallable, BlueprintEvent)
// Parameters:
// EAthenaGamePhaseStep           Step                           (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)

void UAthenaGamePhaseChangeWid::PlayGamePhaseAlertSound(EAthenaGamePhaseStep Step)
{
	static UFunction* fn;

		if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AthenaGamePhaseChangeWidget.AthenaGamePhaseChangeWid.PlayGamePhaseAlertSound"));

	UAthenaGamePhaseChangeWid_PlayGamePhaseAlertSound_Params params;
	params.Step = Step;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AthenaGamePhaseChangeWidget.AthenaGamePhaseChangeWid.UpdateMessaging
// (Event, Protected, HasOutParms, BlueprintEvent)
// Parameters:
// EAthenaGamePhaseStep*          Step                           (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
// struct FText*                  MESSAGE                        (ConstParm, BlueprintVisible, BlueprintReadOnly, Parm, OutParm, ReferenceParm)
// struct FText*                  TimeText                       (ConstParm, BlueprintVisible, BlueprintReadOnly, Parm, OutParm, ReferenceParm)

void UAthenaGamePhaseChangeWid::UpdateMessaging(EAthenaGamePhaseStep* Step, struct FText* MESSAGE, struct FText* TimeText)
{
	static UFunction* fn;

		if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AthenaGamePhaseChangeWidget.AthenaGamePhaseChangeWid.UpdateMessaging"));

	UAthenaGamePhaseChangeWid_UpdateMessaging_Params params;
	params.Step = Step;
	params.MESSAGE = MESSAGE;
	params.TimeText = TimeText;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AthenaGamePhaseChangeWidget.AthenaGamePhaseChangeWid.OnAnimationFinished
// (BlueprintCosmetic, Event, Public, BlueprintEvent)
// Parameters:
// class UWidgetAnimation**       Animation                      (ConstParm, BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, InstancedReference, IsPlainOldData)

void UAthenaGamePhaseChangeWid::OnAnimationFinished(class UWidgetAnimation** Animation)
{
	static UFunction* fn;

		if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AthenaGamePhaseChangeWidget.AthenaGamePhaseChangeWid.OnAnimationFinished"));

	UAthenaGamePhaseChangeWid_OnAnimationFinished_Params params;
	params.Animation = Animation;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AthenaGamePhaseChangeWidget.AthenaGamePhaseChangeWid.GamePhaseStepChanged
// (Event, Protected, BlueprintEvent)
// Parameters:
// EAthenaGamePhaseStep*          Step                           (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)

void UAthenaGamePhaseChangeWid::GamePhaseStepChanged(EAthenaGamePhaseStep* Step)
{
	static UFunction* fn;

		if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AthenaGamePhaseChangeWidget.AthenaGamePhaseChangeWid.GamePhaseStepChanged"));

	UAthenaGamePhaseChangeWid_GamePhaseStepChanged_Params params;
	params.Step = Step;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AthenaGamePhaseChangeWidget.AthenaGamePhaseChangeWid.Construct
// (BlueprintCosmetic, Event, Public, BlueprintEvent)

void UAthenaGamePhaseChangeWid::Construct()
{
	static UFunction* fn;

		if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AthenaGamePhaseChangeWidget.AthenaGamePhaseChangeWid.Construct"));

	UAthenaGamePhaseChangeWid_Construct_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AthenaGamePhaseChangeWidget.AthenaGamePhaseChangeWid.ExecuteUbergraph_AthenaGamePh
// (HasDefaults)
// Parameters:
// int                            EntryPoint                     (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)

void UAthenaGamePhaseChangeWid::ExecuteUbergraph_AthenaGamePh(int EntryPoint)
{
	static UFunction* fn;

		if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AthenaGamePhaseChangeWidget.AthenaGamePhaseChangeWid.ExecuteUbergraph_AthenaGamePh"));

	UAthenaGamePhaseChangeWid_ExecuteUbergraph_AthenaGamePh_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
