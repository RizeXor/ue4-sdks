// Fortnite (2.3.2) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "FN_Announce_BuildingDamaged_parameters.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function Announce_BuildingDamaged.Announce_BuildingDamaged.UserConstructionScript
// (Event, Public, BlueprintCallable, BlueprintEvent)

void AAnnounce_BuildingDamaged::UserConstructionScript()
{
	static UFunction* fn;

		if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function Announce_BuildingDamaged.Announce_BuildingDamaged.UserConstructionScript"));

	AAnnounce_BuildingDamaged_UserConstructionScript_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Announce_BuildingDamaged.Announce_BuildingDamaged.OnClientAnnouncementStart
// (BlueprintCosmetic, Event, Protected, BlueprintEvent)

void AAnnounce_BuildingDamaged::OnClientAnnouncementStart()
{
	static UFunction* fn;

		if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function Announce_BuildingDamaged.Announce_BuildingDamaged.OnClientAnnouncementStart"));

	AAnnounce_BuildingDamaged_OnClientAnnouncementStart_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Announce_BuildingDamaged.Announce_BuildingDamaged.ExecuteUbergraph_Announce_BuildingDamaged
// ()
// Parameters:
// int                            EntryPoint                     (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)

void AAnnounce_BuildingDamaged::ExecuteUbergraph_Announce_BuildingDamaged(int EntryPoint)
{
	static UFunction* fn;

		if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function Announce_BuildingDamaged.Announce_BuildingDamaged.ExecuteUbergraph_Announce_BuildingDamaged"));

	AAnnounce_BuildingDamaged_ExecuteUbergraph_Announce_BuildingDamaged_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
