#pragma once

// Fortnite (2.3.2) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "FN_Announcement_ZoneModifiers_classes.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Announcement_ZoneModifiers.Announcement_ZoneM.UpdateWidgetData
struct UAnnouncement_ZoneM_UpdateWidgetData_Params
{
	class AFortClientAnnouncement**                    Announcement;                                             // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Announcement_ZoneModifiers.Announcement_ZoneM.OnDisplayTimerFinished
struct UAnnouncement_ZoneM_OnDisplayTimerFinished_Params
{
};

// Function Announcement_ZoneModifiers.Announcement_ZoneM.OnConversationDelay
struct UAnnouncement_ZoneM_OnConversationDelay_Params
{
};

// Function Announcement_ZoneModifiers.Announcement_ZoneM.WidgetCachingHack
struct UAnnouncement_ZoneM_WidgetCachingHack_Params
{
};

// Function Announcement_ZoneModifiers.Announcement_ZoneM.ExecuteUbergraph_Announcement_ZoneModifiers
struct UAnnouncement_ZoneM_ExecuteUbergraph_Announcement_ZoneModifiers_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
