// Fortnite (2.3.2) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "FN_AbilitiesPage_parameters.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function AbilitiesPage.AbilitiesPage_C.Handl
// (Public, HasOutParms, BlueprintCallable, BlueprintEvent)
// Parameters:
// bool                           Passthrough                    (Parm, OutParm, ZeroConstructor, IsPlainOldData)

void UAbilitiesPage_C::Handl(bool* Passthrough)
{
	static UFunction* fn;

		if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AbilitiesPage.AbilitiesPage_C.Handl"));

	UAbilitiesPage_C_Handl_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;

	if (Passthrough != nullptr)
		*Passthrough = params.Passthrough;
}


// Function AbilitiesPage.AbilitiesPage_C.UpdateAbilityMovie
// (Public, BlueprintCallable, BlueprintEvent)
// Parameters:
// class UFortGadgetItemDefinition* inGadgetItemDef                (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)

void UAbilitiesPage_C::UpdateAbilityMovie(class UFortGadgetItemDefinition* inGadgetItemDef)
{
	static UFunction* fn;

		if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AbilitiesPage.AbilitiesPage_C.UpdateAbilityMovie"));

	UAbilitiesPage_C_UpdateAbilityMovie_Params params;
	params.inGadgetItemDef = inGadgetItemDef;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AbilitiesPage.AbilitiesPage_C.InitializeAbilityTiles
// (Public, HasDefaults, BlueprintCallable, BlueprintEvent)

void UAbilitiesPage_C::InitializeAbilityTiles()
{
	static UFunction* fn;

		if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AbilitiesPage.AbilitiesPage_C.InitializeAbilityTiles"));

	UAbilitiesPage_C_InitializeAbilityTiles_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AbilitiesPage.AbilitiesPage_C.AddTilesToButtonGroup
// (Public, BlueprintCallable, BlueprintEvent)
// Parameters:
// class UVerticalBox*            ButtonContainer                (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, InstancedReference, IsPlainOldData)

void UAbilitiesPage_C::AddTilesToButtonGroup(class UVerticalBox* ButtonContainer)
{
	static UFunction* fn;

		if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AbilitiesPage.AbilitiesPage_C.AddTilesToButtonGroup"));

	UAbilitiesPage_C_AddTilesToButtonGroup_Params params;
	params.ButtonContainer = ButtonContainer;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AbilitiesPage.AbilitiesPage_C.OnAbilitySelected
// (Public, HasDefaults, BlueprintCallable, BlueprintEvent)
// Parameters:
// class UCommonButton*           AbilityButton                  (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, InstancedReference, IsPlainOldData)

void UAbilitiesPage_C::OnAbilitySelected(class UCommonButton* AbilityButton)
{
	static UFunction* fn;

		if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AbilitiesPage.AbilitiesPage_C.OnAbilitySelected"));

	UAbilitiesPage_C_OnAbilitySelected_Params params;
	params.AbilityButton = AbilityButton;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AbilitiesPage.AbilitiesPage_C.OnActivated
// (Event, Protected, BlueprintEvent)

void UAbilitiesPage_C::OnActivated()
{
	static UFunction* fn;

		if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AbilitiesPage.AbilitiesPage_C.OnActivated"));

	UAbilitiesPage_C_OnActivated_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AbilitiesPage.AbilitiesPage_C.OnQuickbarContentsChanged
// (HasOutParms, BlueprintCallable, BlueprintEvent)
// Parameters:
// EFortQuickBars                 QuickbarIndex                  (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
// TArray<int>                    ChangedSlots                   (ConstParm, BlueprintVisible, BlueprintReadOnly, Parm, OutParm, ZeroConstructor, ReferenceParm)

void UAbilitiesPage_C::OnQuickbarContentsChanged(EFortQuickBars QuickbarIndex, TArray<int> ChangedSlots)
{
	static UFunction* fn;

		if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AbilitiesPage.AbilitiesPage_C.OnQuickbarContentsChanged"));

	UAbilitiesPage_C_OnQuickbarContentsChanged_Params params;
	params.QuickbarIndex = QuickbarIndex;
	params.ChangedSlots = ChangedSlots;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AbilitiesPage.AbilitiesPage_C.Construct
// (BlueprintCosmetic, Event, Public, BlueprintEvent)

void UAbilitiesPage_C::Construct()
{
	static UFunction* fn;

		if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AbilitiesPage.AbilitiesPage_C.Construct"));

	UAbilitiesPage_C_Construct_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AbilitiesPage.AbilitiesPage_C.OnDeactivated
// (Event, Protected, BlueprintEvent)

void UAbilitiesPage_C::OnDeactivated()
{
	static UFunction* fn;

		if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AbilitiesPage.AbilitiesPage_C.OnDeactivated"));

	UAbilitiesPage_C_OnDeactivated_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function AbilitiesPage.AbilitiesPage_C.ExecuteUbergraph_AbilitiesPage
// (HasDefaults)
// Parameters:
// int                            EntryPoint                     (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)

void UAbilitiesPage_C::ExecuteUbergraph_AbilitiesPage(int EntryPoint)
{
	static UFunction* fn;

		if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function AbilitiesPage.AbilitiesPage_C.ExecuteUbergraph_AbilitiesPage"));

	UAbilitiesPage_C_ExecuteUbergraph_AbilitiesPage_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
