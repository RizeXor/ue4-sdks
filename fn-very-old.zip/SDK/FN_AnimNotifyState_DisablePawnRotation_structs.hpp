#pragma once

// Fortnite (2.3.2) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "FN_Basic.hpp"
#include "FN_Engine_classes.hpp"

namespace SDK
{
}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
