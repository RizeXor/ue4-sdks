#pragma once

// Fortnite (2.3.2) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "FN_Basic.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Enums
//---------------------------------------------------------------------------

// UserDefinedEnum AthenaDragDropAction.AthenaDragDropAction
enum class EAthenaDragDropAction : uint8_t
{
	NewEnumerator0                 = 0,
	NewEnumerator1                 = 1,
	NewEnumerator2                 = 2,
	NewEnumerator3                 = 3,
	AthenaDragDropAction_MAX       = 4
};



}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
