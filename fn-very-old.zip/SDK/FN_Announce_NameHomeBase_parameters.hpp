#pragma once

// Fortnite (2.3.2) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "FN_Announce_NameHomeBase_classes.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Announce_NameHomeBase.Announce_NameHomeBase_C.UserConstructionScript
struct AAnnounce_NameHomeBase_C_UserConstructionScript_Params
{
};

// Function Announce_NameHomeBase.Announce_NameHomeBase_C.InitAnnouncement
struct AAnnounce_NameHomeBase_C_InitAnnouncement_Params
{
};

// Function Announce_NameHomeBase.Announce_NameHomeBase_C.Handl
struct AAnnounce_NameHomeBase_C_Handl_Params
{
	int*                                               SentenceIdx;                                              // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Announce_NameHomeBase.Announce_NameHomeBase_C.ExecuteUbergraph_Announce_NameHomeBase
struct AAnnounce_NameHomeBase_C_ExecuteUbergraph_Announce_NameHomeBase_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
