#pragma once

// Fortnite (2.3.2) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "FN_AlterationWidgetButton_classes.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function AlterationWidgetButton.AlterationWidgetButton_C.Setup Triangles
struct UAlterationWidgetButton_C_Setup_Triangles_Params
{
};

// Function AlterationWidgetButton.AlterationWidgetButton_C.Update Colors
struct UAlterationWidgetButton_C_Update_Colors_Params
{
};

// Function AlterationWidgetButton.AlterationWidgetButton_C.IntroStart
struct UAlterationWidgetButton_C_IntroStart_Params
{
};

// Function AlterationWidgetButton.AlterationWidgetButton_C.IntroReset
struct UAlterationWidgetButton_C_IntroReset_Params
{
};

// Function AlterationWidgetButton.AlterationWidgetButton_C.TriggerModificationAnimation
struct UAlterationWidgetButton_C_TriggerModificationAnimation_Params
{
};

// Function AlterationWidgetButton.AlterationWidgetButton_C.OnSetup
struct UAlterationWidgetButton_C_OnSetup_Params
{
};

// Function AlterationWidgetButton.AlterationWidgetButton_C.Construct
struct UAlterationWidgetButton_C_Construct_Params
{
};

// Function AlterationWidgetButton.AlterationWidgetButton_C.ExecuteUbergraph_AlterationWidgetButton
struct UAlterationWidgetButton_C_ExecuteUbergraph_AlterationWidgetButton_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
