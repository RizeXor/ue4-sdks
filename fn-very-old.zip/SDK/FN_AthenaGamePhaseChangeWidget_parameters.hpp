#pragma once

// Fortnite (2.3.2) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "FN_AthenaGamePhaseChangeWidget_classes.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function AthenaGamePhaseChangeWidget.AthenaGamePhaseChangeWid.Simpl
struct UAthenaGamePhaseChangeWid_Simpl_Params
{
};

// Function AthenaGamePhaseChangeWidget.AthenaGamePhaseChangeWid.PlayIntroAnimation
struct UAthenaGamePhaseChangeWid_PlayIntroAnimation_Params
{
	EAthenaGamePhaseStep                               Step;                                                     // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function AthenaGamePhaseChangeWidget.AthenaGamePhaseChangeWid.PlayGamePhaseAlertSound
struct UAthenaGamePhaseChangeWid_PlayGamePhaseAlertSound_Params
{
	EAthenaGamePhaseStep                               Step;                                                     // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function AthenaGamePhaseChangeWidget.AthenaGamePhaseChangeWid.UpdateMessaging
struct UAthenaGamePhaseChangeWid_UpdateMessaging_Params
{
	EAthenaGamePhaseStep*                              Step;                                                     // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
	struct FText*                                      MESSAGE;                                                  // (ConstParm, BlueprintVisible, BlueprintReadOnly, Parm, OutParm, ReferenceParm)
	struct FText*                                      TimeText;                                                 // (ConstParm, BlueprintVisible, BlueprintReadOnly, Parm, OutParm, ReferenceParm)
};

// Function AthenaGamePhaseChangeWidget.AthenaGamePhaseChangeWid.OnAnimationFinished
struct UAthenaGamePhaseChangeWid_OnAnimationFinished_Params
{
	class UWidgetAnimation**                           Animation;                                                // (ConstParm, BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
};

// Function AthenaGamePhaseChangeWidget.AthenaGamePhaseChangeWid.GamePhaseStepChanged
struct UAthenaGamePhaseChangeWid_GamePhaseStepChanged_Params
{
	EAthenaGamePhaseStep*                              Step;                                                     // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function AthenaGamePhaseChangeWidget.AthenaGamePhaseChangeWid.Construct
struct UAthenaGamePhaseChangeWid_Construct_Params
{
};

// Function AthenaGamePhaseChangeWidget.AthenaGamePhaseChangeWid.ExecuteUbergraph_AthenaGamePh
struct UAthenaGamePhaseChangeWid_ExecuteUbergraph_AthenaGamePh_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
