#pragma once

// Fortnite (2.3.2) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "FN_AthenaAerialFeedback_structs.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// WidgetBlueprintGenerated AthenaAerialFeedback.AthenaAerialFeedback_C
// 0x0008 (0x0250 - 0x0248)
class UAthenaAerialFeedback_C : public UAthenaHUDSituationalFeed
{
public:
	struct FPointerToUberGraphFrame                    UberGraphFrame;                                           // 0x0248(0x0008) (Transient, DuplicateTransient)

	static UClass* StaticClass()
	{
		static UClass* ptr;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("WidgetBlueprintGenerated AthenaAerialFeedback.AthenaAerialFeedback_C"));

		return ptr;
	}


	void Update();
	void OnLocalPlayerBeginSkydiving_Bind();
	void GamePhaseStepChanged(EAthenaGamePhaseStep GamePhaseStep);
	void OnKeybindsChanged_Bind();
	void Construct();
	void Tick(struct FGeometry* MyGeometry, float* InDel);
	void ExecuteUbergraph_AthenaAerialFeedback(int EntryPoint);
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
