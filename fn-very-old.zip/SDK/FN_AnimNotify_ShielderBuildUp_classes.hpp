#pragma once

// Fortnite (2.3.2) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "FN_AnimNotify_ShielderBuildUp_structs.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass AnimNotify_ShielderBuildUp.AnimNotify_ShielderBuild
// 0x0000 (0x0038 - 0x0038)
class UAnimNotify_ShielderBuild : public UAnimNotify
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr;
		if(!ptr)
			ptr = UObject::FindClass(_xor_("BlueprintGeneratedClass AnimNotify_ShielderBuildUp.AnimNotify_ShielderBuild"));

		return ptr;
	}


	bool Received_Notify(class USkeletalMeshComponent** MeshComp, class UAnimSequenceBase** Animation);
};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
