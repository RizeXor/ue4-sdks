// Fortnite (2.3.2) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "FN_Announcement_ZoneModifiers_parameters.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function Announcement_ZoneModifiers.Announcement_ZoneM.UpdateWidgetData
// (BlueprintCosmetic, Event, Public, BlueprintEvent)
// Parameters:
// class AFortClientAnnouncement** Announcement                   (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)

void UAnnouncement_ZoneM::UpdateWidgetData(class AFortClientAnnouncement** Announcement)
{
	static UFunction* fn;

		if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function Announcement_ZoneModifiers.Announcement_ZoneM.UpdateWidgetData"));

	UAnnouncement_ZoneM_UpdateWidgetData_Params params;
	params.Announcement = Announcement;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Announcement_ZoneModifiers.Announcement_ZoneM.OnDisplayTimerFinished
// (BlueprintCallable, BlueprintEvent)

void UAnnouncement_ZoneM::OnDisplayTimerFinished()
{
	static UFunction* fn;

		if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function Announcement_ZoneModifiers.Announcement_ZoneM.OnDisplayTimerFinished"));

	UAnnouncement_ZoneM_OnDisplayTimerFinished_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Announcement_ZoneModifiers.Announcement_ZoneM.OnConversationDelay
// (BlueprintCallable, BlueprintEvent)

void UAnnouncement_ZoneM::OnConversationDelay()
{
	static UFunction* fn;

		if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function Announcement_ZoneModifiers.Announcement_ZoneM.OnConversationDelay"));

	UAnnouncement_ZoneM_OnConversationDelay_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Announcement_ZoneModifiers.Announcement_ZoneM.WidgetCachingHack
// (BlueprintCallable, BlueprintEvent)

void UAnnouncement_ZoneM::WidgetCachingHack()
{
	static UFunction* fn;

		if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function Announcement_ZoneModifiers.Announcement_ZoneM.WidgetCachingHack"));

	UAnnouncement_ZoneM_WidgetCachingHack_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Announcement_ZoneModifiers.Announcement_ZoneM.ExecuteUbergraph_Announcement_ZoneModifiers
// (HasDefaults)
// Parameters:
// int                            EntryPoint                     (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)

void UAnnouncement_ZoneM::ExecuteUbergraph_Announcement_ZoneModifiers(int EntryPoint)
{
	static UFunction* fn;

		if(!fn)
		fn = UObject::FindObject<UFunction>(_xor_("Function Announcement_ZoneModifiers.Announcement_ZoneM.ExecuteUbergraph_Announcement_ZoneModifiers"));

	UAnnouncement_ZoneM_ExecuteUbergraph_Announcement_ZoneModifiers_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
